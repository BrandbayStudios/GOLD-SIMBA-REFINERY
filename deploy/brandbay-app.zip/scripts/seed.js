// Loads BrandBay's existing website content (copy, services, portfolio, FAQs, testimonials)
// into an empty database. Safe to re-run: each table is only seeded when it is empty.
const bcrypt = require('bcryptjs');
const { get, run, transaction } = require('../src/db');
const { setSetting, getSettings } = require('../src/lib');
const POSTS = require('./posts');

// Starting-price packages shown on /packages; edited later in Admin → Packages.
const PACKAGES = [
  {
    name: 'Logo Design', label: 'Starter', price: 1500,
    tagline: 'A complete logo and stationery set to launch your brand.',
    best_for: 'New businesses, start-ups and side hustles',
    features: ['Full logo design', 'Full business description, written for you', 'Logo guidelines', 'Logo mockups', 'Letterhead design', 'Business card design'],
    timeline: '5–7 working days',
  },
  {
    name: 'Brand Identity', label: 'Essentials', price: 2500,
    tagline: 'Your logo and stationery plus a professional company profile.',
    best_for: 'Small businesses ready to look established',
    features: ['Everything in Logo Design', 'Company profile design (10–12 pages)', 'Email header design'],
    timeline: '7–10 working days',
  },
  {
    name: 'Business Launch', label: 'Growth', price: 4500, highlighted: 1,
    tagline: 'Everything you need to launch and market your business.',
    best_for: 'Businesses launching, rebranding or bidding for contracts',
    features: ['Everything in Logo Design', 'Everything in Brand Identity', 'Social media post templates'],
    timeline: '10–14 working days',
  },
  {
    name: 'Brand + Website', label: 'Premium', price: 7500,
    tagline: 'Your full brand identity plus a professional website.',
    best_for: 'Businesses that want to win customers online',
    features: ['Everything in Logo Design', 'Everything in Brand Identity', 'Website of up to 5 pages, built for mobile', 'Contact / quote form and WhatsApp chat button', 'Google Maps location and basic SEO setup', 'Google Business Profile setup', '1 month of website support'],
    timeline: '2–4 weeks',
  },
];

// Items for the instant quote estimator (/quote); starting prices edited in Admin → Quote estimator.
const ESTIMATE_ITEMS = [
  ['Branding', 'Logo design', 1000, '', 0, 'Original logo with revisions'],
  ['Branding', 'Logo guidelines & mockups', 300, '', 0, 'How to use your logo, shown on real items'],
  ['Branding', 'Business description writing', 500, '', 0, 'Your story, written professionally'],
  ['Branding', 'Business card design', 200, '', 0, ''],
  ['Branding', 'Letterhead design', 400, '', 0, ''],
  ['Branding', 'Email header / signature design', 300, '', 0, ''],
  ['Branding', 'Company profile design (10–12 pages)', 1000, '', 0, 'For tenders, investors and clients'],
  ['Branding', 'Full brand guidelines', 1000, '', 0, 'Colours, fonts and rules for your brand'],
  ['Social media', 'Social media post templates (set of 5)', 500, 'per set', 1, 'Editable, on-brand templates'],
  ['Social media', 'Social media page setup', 500, '', 0, 'Profile, cover and bio for your pages'],
  ['Social media', 'Social media management (15 posts)', 2000, 'per month', 1, '15 designed posts, planned and published'],
  ['Social media', 'Social media & SEO page growth', 3500, 'per month', 1, 'Grow your followers and search visibility'],
  ['Website', 'Business website (up to 5 pages)', 4500, '', 0, 'Mobile friendly, with contact form and WhatsApp button'],
  ['Website', 'Extra website page', 400, 'per page', 1, ''],
  ['Website', 'Online store (e-commerce)', 8000, '', 0, 'Sell products online'],
  ['Website', 'Google Business Profile setup', 650, '', 0, 'Show up on Google Search and Maps'],
  ['Print design', 'Flyer or poster design', 300, 'per design', 1, 'Design only; printing quoted separately'],
  ['Print design', 'Pull-up banner design', 400, 'per design', 1, ''],
  ['Print design', 'Brochure design', 600, '', 0, ''],
  ['Print design', 'Event branding kit', 1200, '', 0, 'Backdrop, banners and social graphics'],
];

function insertEstimateItems() {
  ESTIMATE_ITEMS.forEach(([category, name, price, unit, hasQty, description], i) => {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (get('SELECT id FROM estimate_items WHERE slug = ?', slug)) return;
    run('INSERT INTO estimate_items (slug, name, category, description, price, unit, has_qty, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      slug, name, category, description || null, price, unit || null, hasQty, i);
  });
}

function insertPackages() {
  PACKAGES.forEach((p, i) => {
    const slug = p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (get('SELECT id FROM packages WHERE slug = ?', slug)) return;
    run('INSERT INTO packages (slug, name, label, price, tagline, best_for, features, timeline, highlighted, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      slug, p.name, p.label, p.price, p.tagline, p.best_for, p.features.join('\n'), p.timeline, p.highlighted || 0, i);
  });
}
const invoicing = require('../src/invoicing');

const SETTINGS = {
  site_name: 'BrandBay Innovation Studios',
  tagline: 'Brand | Build | Boost',
  hero_title: 'Where Bold Brands Are Engineered to Win.',
  hero_text:
    'At BrandBay Innovation Studios, we merge strategy, design, and digital innovation to build brands that command attention, influence markets, and scale with precision.',
  phone: '+260972015689',
  whatsapp: '260972015689',
  email: 'info@brandbaystudios.online',
  address_1: 'Cairo Road, Lusaka, Zambia',
  address_2: 'Mpongwe, Copperbelt Zambia',
  facebook_url: '',
  instagram_url: '',
  linkedin_url: '',
  payment_instructions:
    'Once we confirm your order we will send Mobile Money and bank details to your email and phone. Please use your order reference as the payment reference.',
  terms:
    'Payment structure\n\nServices are billed on a 70% upfront deposit and 30% upon completion. Printing jobs may require full or higher upfront payment depending on production requirements. Custom quotes are provided based on project scope and complexity.\n\nTimelines\n\nGraphic design projects: 3–7 working days. Branding projects: 5–14 working days. Website development: 1–4 weeks. Printing turnaround varies based on quantity and specifications. Timelines start once the deposit and all required content have been received.\n\nDeliverables and source files\n\nUpon full payment, clients receive final deliverables in appropriate formats. Editable/source files (e.g. AI, PSD, Canva) can be provided upon request, depending on the project agreement.\n\nChanges after completion\n\nPost-delivery changes are treated as a new request or billed separately, depending on the scope. This ensures a structured workflow and protects project timelines.',
};

// Introductions for each service page (unique, location-specific copy for search engines and visitors).
const SERVICE_INTROS = {
  'graphic-design-brand-identity':
    'Your brand identity is the first thing customers judge. BrandBay Innovation Studios designs logos and complete brand identities for startups, SMEs, churches, schools and corporates in Lusaka and across Zambia — from naming and strategy to colour palettes, typography and brand guidelines your team can actually use.\n\nEvery identity starts with your market and your audience, so the result looks professional on a shop sign in Lusaka, a social media profile and a tender document alike.',
  'digital-advertising-marketing':
    'We help Zambian businesses turn online visibility into enquiries and sales. Our team plans and runs social media marketing on Facebook, Instagram, TikTok and LinkedIn, manages paid advertising campaigns, writes content, sets up email marketing and improves search engine optimisation (SEO) so customers in Lusaka and beyond can find you on Google.\n\nCampaigns are measured on reach, leads and revenue — not just likes.',
  'technological-solutions':
    'Modern businesses need modern systems. BrandBay designs and builds websites, web apps and e-commerce stores for Zambian businesses, sets up EPOS (point-of-sale) systems for shops and restaurants, and supplies IT hardware and support.\n\nWhether you need a simple company website, an online store that takes Mobile Money, or advice on the right digital tools for your business, we align the technology with your goals and budget.',
  'service-event-branding':
    'Professional presentation builds trust. We design company profiles, corporate documents, presentations, event posters and flyers, pull-up banners and motion graphics for businesses, NGOs, churches and events in Lusaka and the Copperbelt.\n\nFrom a launch event to a tender submission, every touchpoint is designed to look consistent and on-brand.',
  'compliance-business-registration':
    'Strong businesses are built on strong foundations. BrandBay helps entrepreneurs formalise their businesses in Zambia: company and business name registration with PACRA, supplier registration with ZPPA for government tenders, ZRA tax registration (TPIN), and professional business plans and proposals.\n\nWe handle the paperwork so you can focus on running your business — and we can design your brand at the same time.',
  'printing-artistry':
    'Quality printing in Lusaka, designed and produced in one place. We print business cards, flyers and posters, pull-up banners, brochures and company profiles, stickers and labels, branded stationery and event materials.\n\nSend your own artwork or let our designers create it, and we will advise on paper, finishes and quantities so your print looks as good as it does on screen.',
};

const SERVICES = [
  {
    slug: 'graphic-design-brand-identity',
    name: 'Graphic Design & Brand Identity',
    tagline: 'We craft brands that communicate clarity and dominance.',
    items: ['Logo Design', 'Brand Strategy', 'Corporate Branding', 'Product Branding', 'Visual Identity Systems', 'Brand Naming'],
    closing: 'Your brand must speak before you do.',
    icon: 'pen',
  },
  {
    slug: 'digital-advertising-marketing',
    name: 'Digital Advertising & Marketing',
    tagline: 'We turn visibility into revenue.',
    items: ['Search Engine Optimization (SEO)', 'Social Media Marketing', 'Email Marketing', 'Content Strategy', 'Paid Campaign Management'],
    closing: 'Performance is measured. Growth is intentional.',
    icon: 'megaphone',
  },
  {
    slug: 'technological-solutions',
    name: 'Technological Solutions',
    tagline: 'Modern businesses require modern systems.',
    items: ['Website & App Design', 'E-commerce Platforms', 'EPOS Setup', 'IT Hardware & System Support', 'Digital Infrastructure Consulting'],
    closing: 'We align technology with business objectives.',
    icon: 'code',
  },
  {
    slug: 'service-event-branding',
    name: 'Service & Event Branding',
    tagline: 'Professional presentation builds trust and authority.',
    items: ['Company Profile Design', 'Corporate Documents', 'Event Posters & Flyers', 'Pull-Up Banners', 'Motion Graphics'],
    closing: 'Every touchpoint matters.',
    icon: 'calendar',
  },
  {
    slug: 'compliance-business-registration',
    name: 'Compliance & Business Registration',
    tagline: 'We help you formalize and structure your business properly.',
    items: ['Business Registration (PACRA)', 'ZPPA Registration', 'ZRA Tax Registration', 'Business Plans & Proposals'],
    closing: 'Strong businesses are built on strong foundations.',
    icon: 'shield',
  },
  {
    slug: 'printing-artistry',
    name: 'Printing & Artistry Solutions',
    tagline: 'Our printing services include:',
    items: [
      'Business Cards', 'Flyers & Posters', 'Pull-Up Banners', 'Brochures & Company Profiles',
      'Stickers & Labels', 'Event Branding Materials', 'Branded Documents & Stationery',
    ],
    closing: 'Quality you can hold in your hands.',
    icon: 'printer',
  },
];

// Logofolio and posters in the same order as the original website's gallery.
const LOGOS = [
  ['Al Faris Gold Leaching & Refining', 'al-faris'], ['Zambia Innovation Hub', 'zambia-innovation-hub'],
  ['Faiheart Fashion Zone', 'faiheart-fashion-zone'], ['Crafty Hands Furniture', 'crafty-hands'],
  ['The Fashion Fortress', 'the-fashion-fortress'], ['My Melanine ZM', 'my-melanine'], ['Drizzly Bites', 'drizzly-bites'],
  ["Samakayi's BouChic", 'samakayis-bouchic'], ['Mauya Loans', 'mauya-loans'], ['Electric Fusion Bar & Lounge', 'electric-fusion'],
  ['Mark-M Technical Solutions', 'mark-m'], ['Daily Devotion', 'daily-devotion'], ['Esther Chungu', 'esther-chungu'],
  ['Glam Beauty Xperience', 'glam-beauty-xperience'], ['Daily Devotion (dark)', 'daily-devotion-dark'],
  ['La Sienne Nails', 'la-sienne-nails'], ['Lemavko Tailoring & Fashion', 'lemavko'], ["Darlo's Nurture", 'darlos-nurture'],
  ['Entrio', 'entrio'], ['The Treasure Chest', 'the-treasure-chest'], ["Tutee's Cakery", 'tutees-cakery'],
  ['Trinity University', 'trinity-university'], ['Yellow Bird Tailoring & Design', 'yellow-bird'], ['FreshQ Chickens', 'freshq-chickens'],
  ['Ruburma', 'ruburma'], ['Berth MediCare', 'berth-medicare'], ['Cheves Enterprises', 'cheves-enterprises'],
  ['Raine Exquisite Cakes', 'raine-exquisite-cakes'], ['Nails Galore', 'nails-galore'], ['Money Mark Loans', 'money-mark-loans'],
];

const POSTERS = [
  ['Digital Literacy Campaign', 'digital-literacy-campaign'], ["Niza's Beauty Glow", 'nizas-beauty-glow'],
  ['Drizzly Bites Menu', 'drizzly-bites-menu'], ['The Hair Haven', 'the-hair-haven'], ['Yellow Bird Designs & Tailoring', 'yellow-bird-designs'],
  ['DNC Designs', 'dnc-designs'], ['The Treasure Chest Sale', 'treasure-chest-sale'], ['Ruburma Agro Solutions', 'ruburma-agro'],
  ['Mauya Soft Loans', 'mauya-soft-loans'], ['Upskilling Training Opportunity', 'upskilling-training'],
  ["Women's Day Buffet", 'womens-day-buffet'], ['Al Faris Gold Leaching & Refinery', 'al-faris-gold-refinery'],
  ['Mobile Massage', 'mobile-massage'], ['Goldspeed × Yango Partner', 'goldspeed-yango'],
  ['Pasachi i-Store Trade & Save', 'pasachi-istore'], ["Kei'lah's Spa & Hair Lounge", 'keilahs-spa'],
  ['Valentines Platters', 'valentines-platters'],
];

// The first 24 logos appear in the home page "Glimpse of our work" showcase, as on the original site.
const FEATURED_LOGOS = 24;

const COMPLIANCE = [
  ['Certificate of Registration (PACRA)', 'certificate-registration'],
  ['ZRA Taxpayer Registration', 'certificate-zra-tpin'],
  ['ZRA Tax Clearance Certificate', 'certificate-zra-tax-clearance'],
  ['ZPPA Supplier Registration', 'certificate-zppa'],
  ['ZICTA Dealer Certificate', 'certificate-zicta'],
];

const PROJECTS = [
  {
    title: 'Altura', category: 'Brand Identity', image: 'altura',
    summary: 'A complete visual identity for Altura, applied across stationery, apparel, packaging and devices.',
    featured: 1,
  },
  {
    title: 'Daily Devotion', category: 'Brand Identity', image: 'daily-devotion',
    summary: 'Logo, colour palette and typography system for Daily Devotion — "a daily dose of faith".',
    featured: 1,
  },
  {
    title: 'Mauya Loans', category: 'Brand Identity', image: 'mauya-loans-identity',
    summary: 'Brand identity and rollout for Mauya Loans, from mobile app screens to signage, ID cards and print.',
    featured: 1,
  },
  {
    title: 'Femilux', category: 'Social Media Design', image: 'femilux', image_2: 'femilux-2',
    summary: 'Instagram-ready post designs for a beauty brand, built to stay consistent across the feed.',
  },
  {
    title: 'Corporate Social Media Campaign', category: 'Social Media Design', image: 'social-campaign-orange', image_2: 'social-campaign-orange-2',
    summary: 'A series of on-brand social posts covering announcements, recruitment and weekly engagement content.',
    featured: 1,
  },
  {
    title: 'Black Friday Product Campaign', category: 'Digital Advertising', image: 'black-friday-campaign',
    summary: 'Product-led Black Friday creatives designed for paid and organic social placements.',
  },
  {
    title: 'Phone Trade-In Campaign', category: 'Digital Advertising', image: 'phone-trade-in-campaign',
    summary: '"Out with the old, in with the new" — trade-in promotion creatives for a mobile retailer.',
  },
  {
    title: 'Creative Social Media Post Designs', category: 'Social Media Design', image: 'social-posts-blue', image_2: 'social-posts-orange',
    summary: 'Professional social page designs that help businesses boost interaction with potential customers.',
  },
  {
    title: 'Retail Social Media Designs', category: 'Social Media Design', image: 'social-posts-red',
    summary: 'Product showcase posts for a gadget retailer, designed to drive enquiries.',
  },
];

// Company profiles: cover mockups plus the design pages (certificates and personal contact details are left out).
const profilePages = (slug, n) => Array.from({ length: n }, (_, i) => `/media/projects/${slug}/${String(i + 1).padStart(2, '0')}.webp`).join('\n');
const PROFILES = [
  {
    title: 'Kenjess General Dealers', client: 'Kenjess General Dealers Ltd', category: 'Company Profile', image: 'kenjess-profile', image_2: 'kenjess-profile-2',
    summary: 'A bold blue-and-gold company profile for a Zambian general supply company, covering its story, vision, mission and core values.',
  },
  {
    title: 'Elgad Security', client: 'Elgad Security Consultancy and Investigations Limited', category: 'Company Profile', image: 'elgad-security-profile', image_2: 'elgad-security-profile-2',
    summary: 'A striking red-and-black profile for a security and investigations firm, presenting its mission, vision and core values with authority.',
  },
  {
    title: 'Ixicol Business Solutions', client: 'Ixicol Business Solutions', category: 'Company Profile', image: 'ixicol-profile',
    summary: 'A sleek monochrome business profile for a multi-industry enterprise spanning logistics, supply, construction, customs clearing and finance.',
    gallery: profilePages('ixicol-profile', 8),
  },
  {
    title: 'Maukat Developers & Engineering', client: 'Maukat Developers & Engineering Ltd', category: 'Company Profile', image: 'maukat-developers-profile',
    summary: 'A clean, structured profile for a construction and building-supply company: executive summary, core competencies, services, strategy and project work.',
    gallery: profilePages('maukat-developers-profile', 9),
  },
  {
    title: 'Al Faris Gold Refining', client: 'Alfaris Gold Leaching & Refining Limited', category: 'Company Profile', image: 'alfaris-gold-profile',
    summary: 'A premium black-and-orange profile for a gold refining company, built around its services, values and social impact.',
    gallery: profilePages('alfaris-gold-profile', 8),
  },
  {
    title: 'Off-Grid Solar Solutions', client: 'Off-Grid Solar Solutions Limited', category: 'Company Profile', image: 'offgrid-solar-profile',
    summary: 'A fresh green-and-orange profile for a renewable energy contractor, covering its vision, core values, services, target markets and compliance.',
    gallery: profilePages('offgrid-solar-profile', 9),
  },
];

// Websites and web apps built by the studio; screenshots taken from the live sites.
const WEBSITES = [
  {
    image: 'saferoute-logistics-website', title: 'SafeRoute Logistics', client: 'SafeRoute Logistics Limited', url: 'https://saferouteglobal.com/',
    summary: 'A bold, fast website for a Lusaka customs clearing and freight forwarding company, with an instant quote calculator and shipment tracking.',
    tags: 'Quote calculator, Shipment tracking, Service pages, Mobile friendly', pages: 4,
  },
  {
    image: 'discovery-freight-website', title: 'Discovery Freight & Logistics', client: 'Discovery Freight & Logistics', url: 'https://discovery.co.zm/',
    summary: 'Website for a Zambian customs and freight specialist serving every border entry, with service pages, FAQs and a quote request form.',
    tags: 'Quote request form, FAQs, Search-ready, Mobile friendly', pages: 4,
  },
  {
    image: 'alfaris-gold-website', title: 'Al Faris Gold Refinery', client: 'Al Faris Gold Leaching & Refining Ltd', url: 'https://alfarisgoldrefinery.com/',
    summary: 'A premium website for a Lusaka gold refinery covering testing, smelting, safekeeping and gold trading, built to win consultations.',
    tags: 'Consultation booking, WhatsApp chat, Premium design, Mobile friendly', pages: 4,
  },
  {
    image: 'mlik-investments-website', title: 'Mlik Investments', client: 'Mlik Investments Limited', url: 'https://mlikinvestment.com/',
    summary: 'A confident website for a mining, heavy machinery and mineral trading company, designed to turn visitors into commercial quote requests.',
    tags: 'Quote requests, Product & service pages, FAQs, Mobile friendly', pages: 4,
  },
  {
    image: 'saferoute-document-system', title: 'SafeRoute Document Management System', client: 'SafeRoute Logistics Limited', url: '',
    summary: 'A private web app for SafeRoute Logistics to create invoices, quotations and delivery notes, manage customers and print or download documents.',
    tags: 'Web app, Invoices & quotations, Delivery notes, Secure sign-in', pages: 2,
  },
  {
    image: 'maukat-engineering-website', title: 'Maukat Developers & Engineering Website', client: 'Maukat Developers & Engineering Ltd', url: 'https://maukatengineering.com/',
    summary: 'Official website for a Lusaka construction and engineering firm, showcasing its services, material supply and projects.',
    tags: 'Service pages, Project showcase, Quote form, Mobile friendly', pages: 4,
  },
];

// Branding and print jobs photographed on site.
const PRINT_JOBS = [
  {
    image: 'saferoute-vehicle-branding', title: 'SafeRoute Logistics Car Branding', client: 'SafeRoute Logistics Limited', category: 'Vehicle Branding', pages: 4,
    summary: 'Full-side vehicle branding for SafeRoute Logistics: logo, contact details and brand swoosh, turning the company car into a moving billboard.',
    tags: 'Vehicle graphics, Brand colours, Contact details, Durable vinyl',
  },
  {
    image: 'kamint-rear-window-branding', title: 'Kamint Enterprise Car Vinyl Branding', client: 'Kamint Enterprise', category: 'Vehicle Branding', pages: 2,
    summary: 'Car vinyl branding for a GPS tracking company, carrying its logo, full list of services and contact details on the back of the vehicle.',
    tags: 'Car vinyl, Logo & services, Contact details',
  },
  {
    image: 'kamint-signboard', title: 'Kamint Enterprise Signboard', client: 'Kamint Enterprise', category: 'Signage', pages: 2,
    summary: 'A tall, framed roadside signboard for a tracking company, showing its services, phone numbers and email at the office entrance.',
    tags: 'Outdoor signage, Steel frame, Service list',
  },
  {
    image: 'discovery-wall-banner', title: 'Discovery Freight Wall Banner', client: 'Discovery Freight & Logistics', category: 'Signage', pages: 1,
    summary: '"Moving Your Cargo. Moving Your Business." A large outdoor wall banner presenting Discovery’s logistics services and contacts.',
    tags: 'Large-format print, Wall mounted, Outdoor',
  },
  {
    image: 'maukat-wall-banner', title: 'Maukat Developers Wall Banner', client: 'Maukat Developers & Engineering Ltd', category: 'Signage', pages: 1,
    summary: 'A wide perimeter-wall banner for a construction and engineering firm, introducing the company, its services and its values.',
    tags: 'Large-format print, Wall mounted, Installation',
  },
  {
    image: 'izack-shopfront-branding', title: 'Izack Investments Shopfront Branding', client: 'Izack Investments Limited', category: 'Shopfront Branding', pages: 2,
    summary: 'Shopfront and shutter branding for a Lusaka town-centre phone and appliance store: fascia, door panels and a "Welcome to our store" display.',
    tags: 'Shopfront panels, Shutter graphics, Product display',
  },
  {
    image: 'mlik-courier-stickers', title: 'Mlik Courier Branded Stickers', client: 'Mlik Courier & Logistics Ltd', category: 'Stickers & Labels', pages: 1,
    summary: 'Branded parcel stickers for a courier company: logo, contacts and the line "One delivery at a time", printed in sheets.',
    tags: 'Sticker printing, Packaging, Brand colours',
  },
  {
    image: 'mlik-courier-delivery-box', title: 'Mlik Courier Delivery Box Branding', client: 'Mlik Courier & Logistics Ltd', category: 'Vehicle Branding', pages: 2,
    summary: 'Branded delivery boxes for a courier company’s motorbikes, with logo, contacts and the line "One delivery at a time" on every side.',
    tags: 'Delivery box wrap, Motorbike branding, Installation',
  },
  {
    image: 'transformation-beauty-banner', title: 'Transformation Beauty Studio Banner', client: 'Transformation Beauty Studio', category: 'Signage', pages: 1,
    summary: 'An outdoor balcony banner for a Kabwata beauty studio, featuring its models, services, phone number and location.',
    tags: 'Outdoor banner, Photo-led design, Contact details',
  },
  {
    image: 'izeni-resort-signboard', title: 'Izeni Resort Roadside Signboard', client: 'Izeni Resort', category: 'Signage', pages: 2,
    summary: 'A large roadside signboard for a resort, showing its services, photos of the pool, rooms, hall and bar, and directions to the main entrance.',
    tags: 'Roadside signage, Directional sign, Photo panels',
  },
  {
    image: 'mobile-accessories-shopfront', title: 'Mobile Accessories Shopfront Posters', client: '', category: 'Shopfront Branding', pages: 1,
    summary: 'Matching shopfront posters for a phone accessories shop, listing what it sells, from glass protectors and chargers to earpods and memory cards.',
    tags: 'Shopfront posters, Product list, Contact details',
  },
  {
    image: 'habib-exhibition-stand', title: 'Habib Industries Exhibition Stand', client: 'Habib Industries', category: 'Exhibitions & Events', pages: 5,
    summary: 'A complete trade show stand for a packaging manufacturer: header fascia, printed backdrop, pull-up banners, flyers and embroidered caps.',
    tags: 'Exhibition backdrop, Pull-up banners, Flyers, Embroidered caps',
  },
  {
    image: 'kamint-pullup-banner', title: 'Kamint Enterprise Pull-up Banner', client: 'Kamint Enterprise', category: 'Pull-up Banners', pages: 1,
    summary: 'A pull-up banner for a tracking company, setting out its full list of services under the line "Delivering excellence, one track at a time".',
    tags: 'Pull-up banner, Service list',
  },
  {
    image: 'buyzambezi-pullup-banner', title: 'BuyZambezi Pull-up Banner', client: 'BuyZambezi', category: 'Pull-up Banners', pages: 1,
    summary: 'A bold pull-up banner for an African e-commerce platform: "One Africa, One Market".',
    tags: 'Pull-up banner, Launch campaign',
  },
  {
    image: 'toastmasters-pullup-banner', title: 'Toastmasters International Pull-up Banner', client: 'Toastmasters International', category: 'Pull-up Banners', pages: 1,
    summary: 'A pull-up banner presenting the club’s values: Integrity, Respect, Service and Excellence.',
    tags: 'Pull-up banner, Values display',
  },
  {
    image: 'zamcom-pullup-banners', title: 'ZAMCOM Pull-up Banners & Backdrop', client: 'ZAMCOM', category: 'Pull-up Banners', pages: 1,
    summary: 'Pull-up banners for professional programmes and media production, with a branded step-and-repeat backdrop for ZAMCOM and ZAMCOM Radio.',
    tags: 'Pull-up banners, Media backdrop',
  },
  {
    image: 'thrive-aid-pullup-banner', title: 'Thrive Aid Pull-up Banner', client: 'Thrive Aid', category: 'Pull-up Banners', pages: 1,
    summary: 'A pull-up banner for a youth NGO, presenting its vision, mission and thematic areas: education, mentorship and mental health.',
    tags: 'Pull-up banner, NGO, Photo collage',
  },
  {
    image: 'vessels-foundation-tshirts', title: 'The Vessels Foundation T-Shirts', client: 'The Vessels Foundation', category: 'T-Shirt Printing', pages: 1,
    summary: 'Black and white branded T-shirts for a charity foundation, printed with its full-colour logo.',
    tags: 'T-shirt printing, Full-colour logo, Black & white shirts',
  },
  {
    image: 'virtues-cash-tshirts', title: 'Virtues Cash Solution T-Shirts', client: 'Virtues Cash Solution', category: 'T-Shirt Printing', pages: 1,
    summary: 'White staff T-shirts for a finance company, carrying its logo and the line "Building Dreams. Securing Futures".',
    tags: 'T-shirt printing, Staff uniforms',
  },
  {
    image: 'dangote-cement-tshirts', title: 'Dangote Cement Zambia T-Shirts & Mug', client: 'Dangote Cement Zambia', category: 'T-Shirt Printing', pages: 1,
    summary: 'Branded T-shirts and a matching printed mug for Dangote Cement Zambia.',
    tags: 'T-shirt printing, Mug printing, Corporate merchandise',
  },
  {
    image: 'spotless-tshirts', title: 'Spotless T-Shirts', client: 'Spotless', category: 'T-Shirt Printing', pages: 1,
    summary: 'Black T-shirts with the Spotless logo printed in crisp white and red.',
    tags: 'T-shirt printing, Team wear',
  },
  {
    image: 'global-youth-network-tshirts', title: 'Global Youth Network 2025 T-Shirts', client: 'Global Youth Network', category: 'T-Shirt Printing', pages: 1,
    summary: 'Event T-shirts for Global Youth Network 2025, with a bright globe design on sky-blue shirts.',
    tags: 'Event T-shirts, Bulk order',
  },
  {
    image: 'yango-fellowship-tshirts', title: 'Yango Fellowship T-Shirts', client: 'Yango & Zambian National STEM Foundation', category: 'T-Shirt Printing', pages: 1,
    summary: 'Front-and-back printed T-shirts for the Yango Fellowship with the Zambian National STEM Foundation.',
    tags: 'T-shirt printing, Front & back print, Programme wear',
  },
  {
    image: 'richmond-farms-tshirts', title: 'Richmond Farms T-Shirts', client: 'Richmond Farms Limited', category: 'T-Shirt Printing', pages: 1,
    summary: 'Staff T-shirts in the farm’s green, black and white, printed with the Richmond Farms logo.',
    tags: 'T-shirt printing, Staff uniforms, Three colours',
  },
  {
    image: 'excel-tshirts', title: 'Excel "Positioned for Greatness" T-Shirts', client: 'Excel', category: 'T-Shirt Printing', pages: 1,
    summary: 'White T-shirts with an elegant gradient "Excel — Positioned for Greatness" print.',
    tags: 'T-shirt printing, Gradient print',
  },
  {
    image: 'kupes-young-womens-tshirts', title: 'Kupes Young Womens Network T-Shirts', client: 'Kupes Young Womens Network', category: 'T-Shirt Printing', pages: 1,
    summary: 'Black T-shirts for a young women’s network, with a butterfly silhouette logo in pink and purple.',
    tags: 'T-shirt printing, Multi-colour print',
  },
  {
    image: 'why-my-voice-matters-pens', title: '#WhyMyVoiceMatters Branded Pens', client: '', category: 'Branded Merchandise', pages: 1,
    summary: 'Branded white pens for the #WhyMyVoiceMatters campaign, printed with the hashtag and organisation logo.',
    tags: 'Branded pens, Campaign merchandise',
  },
  {
    image: 'why-my-vote-matters-pens', title: '#WhyMyVoteMatters Branded Pens', client: '', category: 'Branded Merchandise', pages: 2,
    summary: 'White and black-and-gold pens for the #WhyMyVoteMatters voter campaign.',
    tags: 'Branded pens, Campaign merchandise',
  },
  {
    image: 'my-limitless-journal', title: 'My Limitless Journal', client: 'Be Limitless', category: 'Branded Merchandise', pages: 1,
    summary: 'Custom leather-look journals in three colours, printed with the "My Limitless Journal" design.',
    tags: 'Branded journals, Notebook printing',
  },
  {
    image: 'mount-zion-bookmarks', title: 'Mount Zion Christian Centre Bookmarks', client: 'Mount Zion Christian Centre', category: 'Flyers & Brochures', pages: 1,
    summary: 'Printed bookmarks carrying the church’s mission statement, logo and cross design.',
    tags: 'Bookmark printing, Church stationery',
  },
  {
    image: 'flames-of-hope-flyers', title: 'Flames of Hope Back to School Flyers', client: 'Flames of Hope Ministries', category: 'Flyers & Brochures', pages: 1,
    summary: 'Flyers for a "Back to School" youth Sunday service, with date, time, location and scripture.',
    tags: 'Flyer design & printing, Event promotion',
  },
  {
    image: 'brookehouse-brochures', title: 'Brookehouse Commodities Brochures', client: 'Brookehouse Commodities Ltd', category: 'Flyers & Brochures', pages: 2,
    summary: 'Folded brochures for an agricultural commodities company, in its navy and green brand colours.',
    tags: 'Brochure design & printing, Folded brochure',
  },
  {
    image: 'be-limitless-tshirts', title: 'Be Limitless T-Shirts', client: 'Be Limitless', category: 'T-Shirt Printing', pages: 1,
    summary: 'White T-shirts printed with the full-colour Be Limitless brain logo, matching the My Limitless Journal.',
    tags: 'T-shirt printing, Full-colour logo',
  },
  {
    image: 'zatu-creatives-tshirts', title: 'Zatu Creatives Foundation T-Shirts', client: 'Zatu Creatives Foundation', category: 'T-Shirt Printing', pages: 1,
    summary: 'Cream T-shirts printed with the Zatu Creatives Foundation logo and its Africa map mark.',
    tags: 'T-shirt printing, Bold one-colour print',
  },
  {
    image: 'namukonda-legacy-tshirts', title: 'The Namukonda Legacy Project T-Shirts', client: 'The Namukonda Legacy Project', category: 'T-Shirt Printing', pages: 1,
    summary: 'White T-shirts for a community project, printed with its caring-hands and heart logo in black and gold.',
    tags: 'T-shirt printing, Full-colour print',
  },
  {
    image: 'zarena-power-elec-embroidery', title: 'ZARENA Polos & Power & Elec Zambia 2025 Caps', client: 'Zambia Renewable Energy Association', category: 'Embroidery', pages: 1,
    summary: 'Embroidered polo shirts for the Zambia Renewable Energy Association and embroidered caps for the Power & Elec Zambia 2025 expo.',
    tags: 'Embroidered polos, Embroidered caps, Event wear',
  },
  {
    image: 'embroidered-polo-shirts', title: 'Embroidered Polo Shirts', client: '', category: 'Embroidery', pages: 1,
    summary: 'Navy polo shirts with an embroidered badge logo, finished and packed for a group order.',
    tags: 'Embroidered badge, Polo shirts, Bulk order',
  },
  {
    image: 'immaculate-conception-shirts', title: 'Immaculate Conception Parish Shirts', client: 'Immaculate Conception Parish, Luanshya', category: 'Embroidery', pages: 1,
    summary: 'White and khaki shirts for Immaculate Conception Parish in Luanshya, with a detailed embroidered parish emblem.',
    tags: 'Embroidered emblem, Church uniforms, Two colours',
  },
  {
    image: 'staff-id-cards', title: 'Staff ID Cards', client: '', category: 'ID Cards & Badges', pages: 1,
    summary: 'Custom-designed photo ID cards for staff and directors of several companies, printed and fitted in clear holders with lanyards.',
    tags: 'ID card design, Photo ID, Holders & lanyards',
  },
  {
    image: 'cwl-name-badges', title: 'Catholic Women’s League Name Badges', client: 'St Matthias Kalemba Parish, Siavonga', category: 'ID Cards & Badges', pages: 1,
    summary: 'Domed name badges for Catholic Women’s League members of St Matthias Kalemba Parish, Siavonga.',
    tags: 'Name badges, Domed finish, Personalised',
  },
  {
    image: 'cfar-business-cards', title: 'CFAR Business Cards', client: 'The African Center for Apologetics Research', category: 'Business Cards', pages: 1,
    summary: 'Business cards for the Regional Director of the African Center for Apologetics Research, with full contact and social details.',
    tags: 'Business card design, Printing',
  },
  {
    image: 'clean-solar-brochures', title: 'Clean Solar ZM Brochures', client: 'Clean Solar ZM', category: 'Flyers & Brochures', pages: 2,
    summary: 'Tri-fold brochures for a solar panel cleaning and maintenance company, with services, socials and contact details.',
    tags: 'Tri-fold brochure, Design & printing',
  },
  {
    image: 'alfaris-office-logo-sign', title: 'Al Faris Office Logo Sign', client: 'Al Faris Gold Leaching & Refining Ltd', category: 'Office Branding', pages: 1,
    summary: 'A raised 3D cut-out logo sign for the Al Faris office wall, with the company name and its line "Purity, Security, and Excellence in Every Ounce".',
    tags: '3D cut-out letters, Office signage, Wall mounted',
  },
  {
    image: 'kamint-fleet-cutouts', title: 'Kamint Enterprise Fleet Cutouts', client: 'Kamint Enterprise', category: 'Vehicle Branding', pages: 3,
    summary: 'Vinyl cut-out logos and contact strips for the Kamint Enterprise fleet: bonnet logos and rear-window branding.',
    tags: 'Vinyl cut-outs, Bonnet logo, Rear window',
  },
  {
    image: 'g100-wall-branding', title: 'G-100 Group Office Wall Branding', client: 'G-100 Group of Companies', category: 'Office Branding', pages: 3,
    summary: 'A full-height framed wall graphic for the G-100 Group office, presenting its divisions: Mining & Mineral Wealth, Hospitality & Tourism, Agriculture, and Energy & Power.',
    tags: 'Wall graphics, Large-format print, Framed panels, Installation',
  },
  {
    image: 'swap-topup-shopfront', title: 'Promjet Solutions Shopfront Branding', client: 'Promjet Solutions', category: 'Shopfront Branding', pages: 2,
    summary: 'Shopfront branding for Promjet Solutions: service panels for phones and electronics, logistics and vehicles, door logos and a lit side display, installed on site by the BrandBay team.',
    tags: 'Shopfront graphics, Lit display, Door logos, On-site installation',
  },
  {
    image: 'rural-ventures-business-cards', title: 'Rural Ventures Limited Business Cards', client: 'Rural Ventures Limited', category: 'Business Cards', pages: 1,
    summary: 'Double-sided business cards in black and yellow for the Managing Director of Rural Ventures Limited.',
    tags: 'Business card design, Double-sided print, Rounded corners',
  },
  {
    image: 'printed-company-profiles', title: 'Printed Company Profiles', client: 'Bertha Medical, Miyogath General Dealers, Scour Cleaning Services', category: 'Company Profile', pages: 1,
    summary: 'Company profiles designed and printed for a medical supplier, a general dealer and a cleaning company.',
    tags: 'Profile design, Printing & binding',
  },
  {
    image: 'kamint-company-profile', title: 'Kamint Enterprise Company Profile', client: 'Kamint Enterprise', category: 'Company Profile', pages: 1,
    summary: 'A landscape company profile for Kamint Enterprise, "Keep track of what matters most", printed and finished with eyelets.',
    tags: 'Profile design, Landscape format, Eyelet binding',
  },
  {
    image: 'mind-solutions-car-cutouts', title: 'Mind Solutions Car Cut-outs', client: 'Mind Solutions', category: 'Vehicle Branding', pages: 1,
    summary: 'A round vinyl cut-out of the Mind Solutions logo on the driver’s door, giving the company car a clean, professional look.',
    tags: 'Vinyl cut-out, Door logo, Vehicle branding',
  },
  {
    image: 'newtech-agro-business-cards', title: 'Newtech Agro Solutions Business Cards', client: 'Newtech Agro Solutions Ltd', category: 'Business Cards', pages: 1,
    summary: 'Business cards for an agribusiness company, in green and charcoal with the logo, contact details and a line on its commodities and grain storage services.',
    tags: 'Business card design, Rounded corners, Brand colours',
  },
  {
    image: 'kamint-office-branding', title: 'Kamint Enterprise Office Branding', client: 'Kamint Enterprise', category: 'Office Branding', pages: 1,
    summary: 'Branding for the Kamint Enterprise office: a large banner on the building, scaffold installation and the "Our Services" signboard at the gate.',
    tags: 'Building banner, On-site installation, Signboard',
  },
  {
    image: 'sashi-gardens-tshirts', title: 'Sashi Gardens T-Shirts', client: 'Sashi Gardens', category: 'T-Shirt Printing', pages: 1,
    summary: 'Black T-shirts printed with the Sashi Gardens logo in crisp white, packed individually.',
    tags: 'T-shirt printing, Staff wear, Individually packed',
  },
  {
    image: 'power-chip-hanchu', slug: 'solar-installation', title: 'Solar Inverter & Battery Installation', client: '', category: 'Solar Installation', pages: 2,
    summary: 'Hybrid solar inverter and lithium battery installations with a neat distribution board and cable trunking, giving homes and offices reliable backup power.',
    tags: 'Hybrid inverter, Lithium battery, Distribution board, Neat trunking',
  },
];

function insertPrintJobs() {
  PRINT_JOBS.forEach((p, i) => {
    if (get('SELECT id FROM projects WHERE slug IN (?, ?)', p.slug || p.image, p.image)) return;
    run(
      'INSERT INTO projects (slug, title, client, category, summary, image, gallery, tags, published, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      p.slug || p.image, p.title, p.client || null, p.category, p.summary, `/media/projects/${p.image}.webp`,
      profilePages(p.image, p.pages), p.tags || null, p.published ?? 1, i - 50,
    );
  });
}

function insertWebsites() {
  WEBSITES.forEach((w, i) => {
    if (get('SELECT id FROM projects WHERE slug = ?', w.image)) return;
    run(
      'INSERT INTO projects (slug, title, client, category, summary, image, gallery, website_url, tags, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      w.image, w.title, w.client, 'Website Design', w.summary, `/media/projects/${w.image}.webp`,
      profilePages(w.image, w.pages), w.url || null, w.tags, i - 100,
    );
  });
}

function insertProfiles() {
  PROFILES.forEach((p, i) => {
    if (get('SELECT id FROM projects WHERE slug = ?', p.image)) return;
    run(
      'INSERT INTO projects (slug, title, client, category, summary, image, image_2, gallery, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      p.image, p.title, p.client, p.category, p.summary, `/media/projects/${p.image}.webp`,
      p.image_2 ? `/media/projects/${p.image_2}.webp` : null, p.gallery || null, i - PROFILES.length,
    );
  });
}

const TESTIMONIALS = [
  {
    name: 'Eugine Mavunga',
    quote: 'BrandBay Innovation Studios transformed our brand identity completely. Their creativity and attention to detail gave our business a professional image that truly stands out.',
  },
  {
    name: 'Wilkins Sikazwe',
    quote: 'Working with BrandBay was a great experience. They don’t just design, they understand business and create solutions that actually help you grow.',
  },
];

const FAQS = [
  [
    'What services does BrandBay Studios offer?',
    'BrandBay Studios provides integrated solutions across technology, branding, graphic design, and printing. Our services include website development, branding and identity design, marketing materials, social media creatives, and high-quality print production. We deliver end-to-end solutions from concept to final output.',
  ],
  [
    'How long do projects typically take?',
    'Timelines depend on the scope of work:\n\nGraphic design projects: 3–7 working days\nBranding projects: 5–14 working days\nWebsite development: 1–4 weeks\nPrinting: turnaround varies based on quantity and specifications',
  ],
  [
    'What is your pricing and payment structure?',
    'We operate on a 70% upfront deposit and 30% upon completion. Printing jobs may require full or higher upfront payment depending on production requirements. Custom quotes are provided based on project scope and complexity.',
  ],
  [
    'Will I get source files and editable formats?',
    'Yes. Upon full payment, clients receive final deliverables in appropriate formats. Editable/source files (e.g., AI, PSD, Canva) can be provided upon request, depending on the project agreement.',
  ],
  [
    'What happens if I need changes after project completion?',
    'Post-delivery changes are treated as a new request or billed separately, depending on the scope. This ensures structured workflow and protects project timelines.',
  ],
  [
    'How do I track my project?',
    'Every request gets a reference number. Create a free account with the same email address you used on the form and you can follow progress, view quotes and message our team from your dashboard.',
  ],
];

// Store items start as unpublished drafts with no price: set real prices in Admin → Products, then publish.
const PRODUCTS = [
  ['Business Cards', 'Printing', 'Full-colour business cards printed on premium card stock. Design available on request.', 'per 100'],
  ['Flyers & Posters', 'Printing', 'A5, A4 and A3 flyers and posters for promotions and events.', 'per 50'],
  ['Pull-Up Banner', 'Printing', 'Free-standing pull-up banner with carry bag — ideal for events and reception areas.', 'each'],
  ['Brochures & Company Profiles', 'Printing', 'Folded brochures and bound company profiles that present your business professionally.', 'per 25'],
  ['Stickers & Labels', 'Printing', 'Custom-cut stickers and product labels in any shape.', 'per sheet'],
  ['Logo Design Package', 'Design', 'Professional logo design with colour variations and final files for print and web.', 'package'],
];

const empty = (table) => !get(`SELECT 1 AS x FROM ${table} LIMIT 1`);

function seed() {
  transaction(() => {
    const existing = getSettings();
    for (const [key, value] of Object.entries(SETTINGS)) {
      if (!(key in existing)) setSetting(key, value);
    }

    if (empty('service_categories')) {
      SERVICES.forEach((s, i) =>
        run(
          'INSERT INTO service_categories (slug, name, tagline, intro, items, closing, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          s.slug, s.name, s.tagline, SERVICE_INTROS[s.slug] || null, s.items.join('\n'), s.closing, s.icon, i,
        ));
    }

    if (empty('gallery_items')) {
      LOGOS.forEach(([title, file], i) =>
        run('INSERT INTO gallery_items (album, title, image, featured, sort_order) VALUES (?, ?, ?, ?, ?)',
          'logos', title, `/media/logos/${file}.webp`, i < FEATURED_LOGOS ? 1 : 0, i));
      POSTERS.forEach(([title, file], i) =>
        run('INSERT INTO gallery_items (album, title, image, sort_order) VALUES (?, ?, ?, ?)',
          'posters', title, `/media/posters/${file}.webp`, i));
      COMPLIANCE.forEach(([title, file], i) =>
        run('INSERT INTO gallery_items (album, title, image, sort_order) VALUES (?, ?, ?, ?)',
          'compliance', title, `/media/about/${file}.webp`, i));
    }

    if (empty('projects')) {
      PROJECTS.forEach((p, i) =>
        run(
          'INSERT INTO projects (slug, title, category, summary, image, image_2, featured, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          p.image, p.title, p.category, p.summary, `/media/projects/${p.image}.webp`,
          p.image_2 ? `/media/projects/${p.image_2}.webp` : null, p.featured || 0, i,
        ));
      insertProfiles();
      insertWebsites();
      insertPrintJobs();
    }

    if (empty('packages')) insertPackages();
    if (empty('estimate_items')) insertEstimateItems();

    if (empty('testimonials')) {
      TESTIMONIALS.forEach((t, i) =>
        run('INSERT INTO testimonials (name, quote, rating, sort_order) VALUES (?, ?, 5, ?)', t.name, t.quote, i));
    }

    if (empty('faqs')) {
      FAQS.forEach(([q, a], i) => run('INSERT INTO faqs (question, answer, sort_order) VALUES (?, ?, ?)', q, a, i));
    }

    if (empty('products')) {
      PRODUCTS.forEach(([name, category, description, unit], i) =>
        run(
          'INSERT INTO products (slug, name, category, description, unit, price, sort_order, published) VALUES (?, ?, ?, ?, ?, 0, ?, 0)',
          name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-$/, ''), name, category, description, unit, i,
        ));
    }

    const { ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME } = process.env;
    if (ADMIN_EMAIL && ADMIN_PASSWORD && !get("SELECT id FROM users WHERE role = 'admin' LIMIT 1")) {
      run(
        "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin') ON CONFLICT(email) DO UPDATE SET role = 'admin'",
        ADMIN_NAME || 'BrandBay Admin', ADMIN_EMAIL, bcrypt.hashSync(ADMIN_PASSWORD, 12),
      );
    }
  });
  invoicing.ensureDefaults();
}

// Fills in content added after a database was first created; never overwrites edited text.
function backfillContent() {
  for (const [slug, intro] of Object.entries(SERVICE_INTROS)) {
    run("UPDATE service_categories SET intro = ? WHERE slug = ? AND (intro IS NULL OR intro = '')", intro, slug);
  }
  // The first release listed the email on a domain that does not exist (brandbaystudio.online, no "s").
  run("UPDATE settings SET value = 'info@brandbaystudios.online' WHERE key = 'email' AND value = 'info@brandbaystudio.online'");
  // One-time: add the packages to databases created before them.
  if (!getSettings().content_packages_v1) {
    transaction(() => { insertPackages(); setSetting('content_packages_v1', '1'); });
  }
  // One-time: add the quote estimator items to databases created before them.
  if (!getSettings().content_estimator_v1) {
    transaction(() => { insertEstimateItems(); setSetting('content_estimator_v1', '1'); });
  }
  // One-time: estimator prices set by the studio (Nov 2026). Existing rows are matched by their original slug.
  if (!getSettings().content_estimator_v2) {
    transaction(() => {
      const prices = {
        'business-description-writing': [500], 'email-header-signature-design': [300], 'letterhead-design': [400],
        'full-brand-guidelines': [1000], 'social-media-page-setup': [500], 'google-business-profile-setup': [650, 'Show up on Google Search and Maps'],
        'pull-up-banner-design': [400], 'social-media-management': [2000, '15 designed posts, planned and published', 'Social media management (15 posts)'],
      };
      for (const [slug, [price, description, name]] of Object.entries(prices)) {
        run('UPDATE estimate_items SET price = ?, description = COALESCE(?, description), name = COALESCE(?, name) WHERE slug = ?', price, description || null, name || null, slug);
      }
      const after = get("SELECT sort_order FROM estimate_items WHERE slug IN ('social-media-management', 'social-media-management-15-posts')");
      if (!get("SELECT id FROM estimate_items WHERE slug = 'social-media-seo-page-growth'")) {
        run("INSERT INTO estimate_items (slug, name, category, description, price, unit, has_qty, sort_order) VALUES ('social-media-seo-page-growth', 'Social media & SEO page growth', 'Social media', 'Grow your followers and search visibility', 3500, 'per month', 1, ?)",
          after ? after.sort_order : 99);
      }
      setSetting('content_estimator_v2', '1');
    });
  }
  // One-time: package contents revised by the studio (Nov 2026).
  if (!getSettings().content_packages_v2) {
    transaction(() => {
      for (const p of PACKAGES) {
        const slug = p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
        run('UPDATE packages SET tagline = ?, best_for = ?, features = ?, timeline = ? WHERE slug = ?',
          p.tagline, p.best_for, p.features.join('\n'), p.timeline, slug);
      }
      setSetting('content_packages_v2', '1');
    });
  }
  // One-time: publish the first Insights articles.
  if (!getSettings().content_posts_v1) {
    transaction(() => {
      POSTS.forEach((p, i) => {
        if (get('SELECT id FROM posts WHERE slug = ?', p.slug)) return;
        run("INSERT INTO posts (slug, title, excerpt, body, image, published, published_at) VALUES (?, ?, ?, ?, ?, 1, datetime('now', ?))",
          p.slug, p.title, p.excerpt, p.body, p.image, `-${i} days`);
      });
      setSetting('content_posts_v1', '1');
    });
  }
  // One-time: Promjet Solutions is the shop behind the Swap & Top Up shopfront; it gets a second photo.
  if (!getSettings().content_print_v7) {
    transaction(() => {
      insertPrintJobs();
      const j = PRINT_JOBS.find((x) => x.image === 'swap-topup-shopfront');
      run('UPDATE projects SET title = ?, client = ?, summary = ?, tags = ?, gallery = ? WHERE slug = ?',
        j.title, j.client, j.summary, j.tags, profilePages(j.image, 2), j.image);
      setSetting('content_print_v7', '1');
    });
  }
  // One-time: the studio named the tab "Office Branding"; the Al Faris office sign belongs there too.
  if (!getSettings().content_office_v1) {
    run("UPDATE projects SET category = 'Office Branding' WHERE category = 'Office & Wall Branding' OR slug = 'alfaris-office-logo-sign'");
    setSetting('content_office_v1', '1');
  }
  // One-time: wall branding, printed profiles, business cards and a shopfront install; a second Kamint signboard photo.
  if (!getSettings().content_print_v6) {
    transaction(() => {
      insertPrintJobs();
      run('UPDATE projects SET gallery = ? WHERE slug = ?', profilePages('kamint-signboard', 2), 'kamint-signboard');
      setSetting('content_print_v6', '1');
    });
  }
  // One-time: embroidery, ID cards, business cards, more print jobs; a second Brookehouse photo.
  if (!getSettings().content_print_v5) {
    transaction(() => {
      insertPrintJobs();
      run('UPDATE projects SET gallery = ? WHERE slug = ?', profilePages('brookehouse-brochures', 2), 'brookehouse-brochures');
      setSetting('content_print_v5', '1');
    });
  }
  // One-time: T-shirt printing, branded merchandise and flyer jobs.
  if (!getSettings().content_print_v4) {
    transaction(() => { insertPrintJobs(); setSetting('content_print_v4', '1'); });
  }
  // One-time: more print, signage, pull-up and exhibition jobs; the Kamint car gets a second photo.
  if (!getSettings().content_print_v3) {
    transaction(() => {
      insertPrintJobs();
      const kamint = PRINT_JOBS.find((j) => j.image === 'kamint-rear-window-branding');
      run('UPDATE projects SET gallery = ? WHERE slug = ?', profilePages(kamint.image, kamint.pages), kamint.image);
      setSetting('content_print_v3', '1');
    });
  }
  // One-time: the studio confirmed the Hanchu photos are its solar installation work and the Kamint job is car vinyl.
  if (!getSettings().content_print_v2) {
    transaction(() => {
      for (const p of PRINT_JOBS.filter((j) => ['power-chip-hanchu', 'kamint-rear-window-branding'].includes(j.image))) {
        run('UPDATE projects SET slug = ?, title = ?, client = ?, category = ?, summary = ?, tags = ?, gallery = ?, published = 1 WHERE slug = ?',
          p.slug || p.image, p.title, p.client || null, p.category, p.summary, p.tags, profilePages(p.image, p.pages), p.image);
      }
      setSetting('content_print_v2', '1');
    });
  }
  // One-time: add the vehicle branding, signage and print projects.
  if (!getSettings().content_print_v1) {
    transaction(() => { insertPrintJobs(); setSetting('content_print_v1', '1'); });
  }
  // One-time: add the website projects to databases created before them.
  if (!getSettings().content_websites_v1) {
    transaction(() => { insertWebsites(); setSetting('content_websites_v1', '1'); });
  }
  // One-time: add the company profile projects to databases created before them.
  if (!getSettings().content_profiles_v1) {
    transaction(() => { insertProfiles(); setSetting('content_profiles_v1', '1'); });
  }
  // One-time: bring the gallery in line with the original site (all designs, original order).
  if (getSettings().content_gallery_v2) return;
  transaction(() => {
    const place = (album, list) => list.forEach(([title, file], i) => {
      const image = `/media/${album}/${file}.webp`;
      const featured = album === 'logos' && i < FEATURED_LOGOS ? 1 : 0;
      const existing = get('SELECT id FROM gallery_items WHERE image = ?', image);
      if (existing) run('UPDATE gallery_items SET sort_order = ?, featured = ? WHERE id = ?', i, featured, existing.id);
      else run('INSERT INTO gallery_items (album, title, image, featured, sort_order) VALUES (?, ?, ?, ?, ?)', album, title, image, featured, i);
    });
    place('logos', LOGOS);
    place('posters', POSTERS);
    setSetting('content_gallery_v2', '1');
  });
}

module.exports = { seed, backfillContent };

if (require.main === module) {
  seed();
  console.log('Seed complete.');
}
